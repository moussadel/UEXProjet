#ifndef ITERATE_H
#define ITERATE_H ITERATE_H

extern int iterate_get_sum (int min, int max);

#endif /* ITERATE_H */
